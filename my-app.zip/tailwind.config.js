module.exports = {
  content: [
    "./src/**/*.{js,jsx,tsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}